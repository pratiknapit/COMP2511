
#include "tree.h"

Tree TreeCopy(Tree t, int depth) {
	// TODO
	return NULL;
}

