
#include <stdlib.h>

#include "tree.h"

bool TreeIsPerfectlyBalanced(Tree t) {
	// TODO
	return false;
}

