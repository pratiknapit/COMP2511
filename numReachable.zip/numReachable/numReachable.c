
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"

int numReachable(Graph g, int src) {
	// TODO
	return -1;
}

