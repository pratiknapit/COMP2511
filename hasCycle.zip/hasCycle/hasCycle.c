
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"
#include "Stack.h"

bool hasCycle(Graph g) {
	// TODO
	return false;
}

