
#include <stdlib.h>

#include "tree.h"

int TreeSumOdds(Tree t) {
	return 0;
}

