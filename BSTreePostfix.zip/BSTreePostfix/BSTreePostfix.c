
#include <stdio.h>

#include "BSTree.h"

void BSTreePostfix(BSTree t) {
	// TODO
}

